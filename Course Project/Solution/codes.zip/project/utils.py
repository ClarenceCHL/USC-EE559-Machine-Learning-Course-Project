import numpy as np
import pandas as pd
from sklearn.model_selection import GridSearchCV, StratifiedKFold
from sklearn.metrics import f1_score, confusion_matrix
import matplotlib.pyplot as plt

def add_time_features(df, cols, duration=5):
    '''
    Add time series features to the dataframe
    '''
    aug_cols=[]
    for col in cols:
        max_col = '{}_{}max'.format(col, duration)
        min_col = '{}_{}min'.format(col, duration)
        mean_col = '{}_{}mean'.format(col, duration)
        aug_cols.append(max_col)
        aug_cols.append(min_col)
        aug_cols.append(mean_col)
        df[max_col] = 0
        df[min_col] = 0
        df[mean_col] = 0
        for i in range(duration, df.shape[0]):
            df.loc[i, max_col] = df.loc[i-duration:i, col].max()
            df.loc[i, min_col] = df.loc[i-duration:i, col].min()
            df.loc[i, mean_col] = df.loc[i-duration:i, col].mean()
    for col in aug_cols:
        df.loc[df[col]==0, col] = df[col].mean()
    return df, aug_cols

def cross_val(train_df, cols, tar_col, classifier, seed=42):
    '''
    Cross validation on the training data
    returns:
        accuracy mean and std
    '''
    X, y = train_df[cols].values, train_df[tar_col].values
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=seed)
    acc = []
    for tr_idx, val_idx in skf.split(X, y):
        classifier.fit(X[tr_idx], y[tr_idx])
        acc.append(classifier.score(X[val_idx], y[val_idx]))
    return np.mean(acc), np.std(acc)

def finetune(train_df, cols, tar_col, classifier, params, seed=42):
    '''
    Model selection on the training data
    returns:
        the best model and validation results
    '''
    X, y = train_df[cols].values, train_df[tar_col].values
    clfs = GridSearchCV(classifier, params)
    clfs.fit(X, y)
    # return results dataframe
    results = pd.DataFrame()
    idx = np.where(np.isnan(clfs.cv_results_['std_test_score'])==False)[0]
    results['params'] = np.array(list(map(str, clfs.cv_results_['params'])))[idx]
    results['mean_val_score'] = clfs.cv_results_['mean_test_score'][idx]
    results['std_val_score'] = clfs.cv_results_['std_test_score'][idx]
    return clfs, results

def get_clf_metrics(test_df, cols, test_y, classifier):
    '''
    Performance of classifier on the test dataset
    returns:
        f1-score, accuracy, confusion_matrix
    '''
    X, y = test_df[cols].values, test_y
    accuracy = classifier.score(X, y)
    y_pred = classifier.predict(X)
    f1 = f1_score(y, y_pred, average='macro')
    conf_matrix = confusion_matrix(y, y_pred)
    return f1, accuracy, conf_matrix

def plot_cnf(cnf, name):
    plt.imshow(cnf)
    for i in range(2):
        for j in range(2):
            plt.text(i, j, str(cnf[i, j]), color='red')
    plt.xticks(np.arange(2), ['Positive', 'Negative'])
    plt.yticks(np.arange(2), ['True', 'False'])
    plt.savefig('./figs/cnf_{}.png'.format(name), dpi=200)
    plt.show()
