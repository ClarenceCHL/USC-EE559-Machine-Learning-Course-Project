import numpy as np


class TrivialClassifier(object):
    def __init__(self, random_state=42):
        np.random.seed(random_state)

    def fit(self, X, y):
        classes = np.unique(y)
        self.classes = classes
        prob = np.zeros(len(classes))
        for i, c in enumerate(classes):
            prob[i] = np.sum(np.where(y==c, 1, 0))
        self.prob = prob / np.sum(prob)

    def predict(self, X):
        y_pred = np.random.choice(self.classes, size=X.shape[0], p=self.prob)
        return y_pred

    def score(self, X, y):
        y_pred = self.predict(X)
        return np.mean(y_pred.ravel() == y.ravel())

class KernelNearestMeansClassifier(object):
    def __init__(self, gamma=0.01, kernel_type='linear'):
        self.gamma = gamma
        self.kernel_type = kernel_type

    def fit(self, X, y):
        self.X_train = X
        self.y_train = y
        

    def predict(self, X):
        X1 = self.X_train[self.y_train==0]
        X2 = self.X_train[self.y_train==1]
        if self.kernel_type == 'rbf':
            dist1 = np.zeros((X1.shape[0], X1.shape[0]))
            for i in range(X1.shape[0]):
                dist1[i, :] = np.sum((X1[i] - X1)**2, axis=1)
            self.K1 = np.mean(np.exp(-self.gamma * dist1))
            
            dist2 = np.zeros((X2.shape[0], X2.shape[0]))
            for i in range(X2.shape[0]):
                dist2[i, :] = np.sum((X2[i] - X2)**2, axis=1)
            self.K2 = np.mean(np.exp(-self.gamma * dist2))

            res = np.zeros((X.shape[0], 2))
            for i in range(X.shape[0]):
                res[i, 0] = -self.K1 + 2 * np.mean(np.exp(-self.gamma * np.sum((X[i] - X1)**2, axis=1)))
                res[i, 1] = -self.K2 + 2 * np.mean(np.exp(-self.gamma * np.sum((X[i] - X2)**2, axis=1)))
        elif self.kernel_type == "linear":
            self.K1 = np.mean(X1 @ X1.T)
            self.K2 = np.mean(X2 @ X2.T)

            res = np.zeros((X.shape[0], 2))
            for i in range(X.shape[0]):
                res[i, 0] = -self.K1 + 2 * np.mean(X[i] @ X1.T)
                res[i, 1] = -self.K2 + 2 * np.mean(X[i] @ X2.T)
        else:
            raise NotImplementedError
        y_pred = np.argmax(res, axis=1)
        return y_pred

    def score(self, X, y):
        y_pred = self.predict(X)
        acc = np.mean(y_pred==y)
        return acc